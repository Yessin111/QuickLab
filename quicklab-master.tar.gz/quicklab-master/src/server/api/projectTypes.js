module.exports = {
  IMPORT_FROM_URL: 'importFromURL',
  IMPORT_FROM_FILE: 'importFromFile',
  FORK_FROM_URL: 'forkFromUrl',
  EMPTY: 'emptyProject',
};
