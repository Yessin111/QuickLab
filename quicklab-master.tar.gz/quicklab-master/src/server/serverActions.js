module.exports = {
  DELETE: 'DELETE_MEMBER',
  ADD: 'ADD',
  RENAME: 'RENAME',
  GROUP_DATA: 'GROUP_DATA',
};
