export const NO_MODAL = 'NO_MODAL';
export const RENAME_MODAL = 'RENAME_MODAL';
export const ADD_GROUP_MODAL = 'GROUP_MODAL';
export const ADD_STUDENT_MODAL = 'STUDENT_MODAL';
export const ADD_PROJECT_MODAL = 'PROJECT_MODAL';
