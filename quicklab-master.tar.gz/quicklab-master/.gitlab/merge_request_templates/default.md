<!-- Change #i to the corresponding issue e.g. #1 -->
Closes #i

## Description

<!-- MR description. What feature does this MR add/What bug does this MR fix? -->

## Checks
- [ ] The program works and compiles.
- [ ] The added functionality is tested.
- [ ] Javadoc is written for new / altered methods
- [ ] Issues have been created for issues outside the scope of this branch

## How to test?
<!-- Brief description on how code reviewers can test added functionality -->

## Known issues
